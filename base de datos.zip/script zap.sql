-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`PROVEEDORES`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`PROVEEDORES` (
  `idPROVEEDOR` INT NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` VARCHAR(15) NOT NULL,
  `ap_paterno` VARCHAR(15) NOT NULL,
  `ap_materno` VARCHAR(15) NOT NULL,
  `telefono` INT(15) NOT NULL,
  PRIMARY KEY (`idPROVEEDOR`),
  UNIQUE INDEX `telefono_UNIQUE` (`telefono` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`ALMACEN`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`ALMACEN` (
  `Id_existencias` INT(5) NOT NULL AUTO_INCREMENT,
  `tipo_zapato` VARCHAR(10) NOT NULL,
  `modelo` VARCHAR(10) NOT NULL,
  `marca` VARCHAR(10) NOT NULL,
  `talla` DECIMAL(5) NOT NULL,
  `color` VARCHAR(8) NOT NULL,
  `precio_compra` INT(5) NOT NULL,
  `precio_venta` INT(5) NOT NULL,
  `numero_pares` INT(8) NOT NULL,
  `PROVEEDORES_idPROVEEDOR` INT NOT NULL,
  PRIMARY KEY (`Id_existencias`),
  INDEX `fk_ALMACEN_PROVEEDORES_idx` (`PROVEEDORES_idPROVEEDOR` ASC),
  CONSTRAINT `fk_ALMACEN_PROVEEDORES`
    FOREIGN KEY (`PROVEEDORES_idPROVEEDOR`)
    REFERENCES `mydb`.`PROVEEDORES` (`idPROVEEDOR`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`VENTA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`VENTA` (
  `Fecha` INT NOT NULL,
  `cantidad_zap` INT(4) NOT NULL,
  `id_ventas` INT(30) UNSIGNED NOT NULL,
  `ALMACEN_Id_existencias` INT(5) NOT NULL,
  PRIMARY KEY (`id_ventas`),
  INDEX `fk_VENTAS_ALMACEN1_idx` (`ALMACEN_Id_existencias` ASC),
  CONSTRAINT `fk_VENTAS_ALMACEN1`
    FOREIGN KEY (`ALMACEN_Id_existencias`)
    REFERENCES `mydb`.`ALMACEN` (`Id_existencias`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`MAS_PARES`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`MAS_PARES` (
  `ID_MAS` VARCHAR(45) NOT NULL,
  `CANTIDAD_PARES` INT NOT NULL,
  `ALMACEN_Id_existencias` INT(5) NOT NULL,
  PRIMARY KEY (`ID_MAS`),
  INDEX `fk_MAS_PARES_ALMACEN1_idx` (`ALMACEN_Id_existencias` ASC),
  CONSTRAINT `fk_MAS_PARES_ALMACEN1`
    FOREIGN KEY (`ALMACEN_Id_existencias`)
    REFERENCES `mydb`.`ALMACEN` (`Id_existencias`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
